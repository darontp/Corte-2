
<?php
$cantidad = $_POST ["cantidad"];
$gastada = $cantidad * 2500;

if($cantidad > 0)
{
echo "<br>cantidad: ", $cantidad ;
echo "<br>valor a pagar: ", $gastada;
}else
{
echo "valor invalido";
}
?>